<!DOCTYPE html>
<html>
<head>
<?php
require "layout/head.php";
?>
</head>
<body>
<?php
require "layout/layout.php";
?>
<p>
<h1>Latest News</h1>
<ul>
<li>New <a href="clock/ClockHome.php">customisable clock</a> to embed on your webpage.</li>
<li>New</li>
</ul>
</p>
<?php
require "layout/sidebar.php";
?>
</body>
</html>