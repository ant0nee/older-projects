</td>
<td id="sidebar" valign="top">
<br />
<center>

<h3>FIND US ON</h3>
<p>[space reserved]</p>
<br />
<h3>NOTICEBOARD</h3>
<p>
<script>
document.write('<iframe src="http://'+location.host+'/noticeboard.htm" ' +
'style="background:#ff6; width:150px;height:150px;border:2px solid black; ">');
</script></iframe>

</p>
</center>
</td>
</tr>
</table>
</div>
</center>